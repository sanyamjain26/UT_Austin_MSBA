library(tidyverse)

# house = read.csv('../data/house.csv')

# let's look at a scatter plot of price versus size
# notice we have three separate neighborhoods here
ggplot(house) +
  geom_point(aes(x=sqft, y=price, color=nbhd))


# if we ignore neighborhood differences, we get a slope of $70/sqft:
lm0 = lm(price ~ sqft, data=house)
coef(lm0) %>% round(0)

# if we account for neighborhood differences, we get a slope of $46/sqft:
lm1 = lm(price ~ sqft + nbhd, data=house)
coef(lm1) %>% round(0)

# it's seems like a paradox: you can get one answer if you group and another
# if you don't group.  Here neighborhood is a confounder for the relationship
# between price and sqft: that's because it's correlated with both variables
# e.g. nbhd3 has the largest, most expensive houses
house %>%
  group_by(nbhd) %>%
  summarize(mean_size = mean(sqft),
            mean_price = mean(price))
