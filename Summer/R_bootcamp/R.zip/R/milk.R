library(tidyverse)

# Import the data

# Looks nonlinear
ggplot(milk) + 
  geom_point(aes(x=price, y=sales))

# A log-log transformations works wonders
# This implies a power law relationship
# also supported by economic theory!
ggplot(milk) + 
  geom_point(aes(x=log(price), y=log(sales))) + 
  geom_smooth(aes(x=log(price), y=log(sales)), method='lm')

# Let's fit the power law by fitting a linear model on a log-log scale
lm1 = lm(log(sales) ~ log(price), data=milk)
coef(lm1)

# interpretation: demand for milk goes down by 1.6% when price goes up by 1%


# what about predicted sales when price = 2.60?
4.72 - 1.62 * log(2.60)
# does this mean we expect to sell 3.17 cartons of milk?!

# no! this is a prediction for log(sales).  it's more like 24 cartons of milk
exp(3.17)
