library(tidyverse)

olympics_top20 = read.csv('../data/olympics_top20.csv')

###
# How do heights compare across summer vs. winter olympics?
###

ggplot(olympics_top20) +
  geom_histogram(aes(x=height))

# faceted histogram
ggplot(olympics_top20) +
  geom_histogram(aes(x=height)) + 
  facet_wrap(~season, nrow=2)

# faceted density histogram
ggplot(olympics_top20) +
  geom_histogram(aes(x=height, y=..density..)) +
  facet_wrap(~season, nrow=2)


###
# Which sports have the oldest athletes?
###

# boxplot of ages by sport
ggplot(olympics_top20) +
  geom_boxplot(aes(x=sport, y=age))

# flipped on its side
ggplot(olympics_top20) +
  geom_boxplot(aes(x=sport, y=age)) +
  coord_flip()

# reordering the boxes by median age
ggplot(olympics_top20) +
  geom_boxplot(aes(x=reorder(sport, age, FUN=median), y=age)) +
  coord_flip()




# has the distribution of ages for Olympic medalists changed over time?
# does that differ for men and women?

# here's a scatter plot, but it's hard
# hard to distinguish the individual points
ggplot(olympics_top20) +
  geom_point(aes(x=year, y=age))

# a jitter plot: a scatter plot with some artificial jitter added
# helps distinguish individual points
# alpha nearer 0 makes the points more transparent
ggplot(olympics_top20) +
  geom_jitter(aes(x=year, y=age), alpha=0.03)

# a little bit more horizontal jitter (~1 year either way)
# saving the plot to add subsequent layers
age_over_time = ggplot(olympics_top20) +
  geom_jitter(aes(x=year, y=age), width=1, alpha=0.03)

age_over_time

# faceted by sex
age_over_time +
  facet_wrap(~sex) 

# some more advanced stuff: add a smooth trend line on top
# to see the mean age over time
age_over_time +
  facet_wrap(~sex) +
  geom_smooth(aes(x=year,y=age))


