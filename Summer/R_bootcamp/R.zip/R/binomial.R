library(tidyverse)

# Example: binomial for airline no shows
# the three key functions to know are:
#   - rbinom: for simulating binomial outcomes
#   - dbinom: for calculating the probability of specific outcomes
#   - pbinom: for calculating cumulative probabilities for a range of outcomes

# Parameters
p_noshow = 0.09  # this is the 'prob' argument to the functions above
n_passengers = 140 # this is the 'size' argument to the functions above

# simulate 5 random flights
rbinom(5, n_passengers, p_noshow)

# dbinom: how likely is a specific outcome, like 7 or 15?
# this is the probability mass function of the binomial, i.e. P(X = k)
# for various possible outcomes k
dbinom(7, n_passengers, p_noshow)  # 3.1% chance of 7 no shows
dbinom(15, n_passengers, p_noshow) # 8.5% chance of 15 no shows

# pbinom: cumulative tail probabilities, P(X <= k)
pbinom(7,  n_passengers, p_noshow)  # 5.8% chance of 7 OR FEWER no shows
pbinom(15,  n_passengers, p_noshow)  # 80.1% chance of 15 OR FEWER no shows

# Suppose you're 12th on the standby list.
# You need at least 12 passengers with seats to no-show.
# What is P(X >= 12)?

#  First, use pbinom to calculate P(X <= 11).
pbinom(11,  n_passengers, p_noshow)

# Now use the fact that P(X >= 12) = 1 - P(X <= 11)
1 - 0.386783

# You can also use lower.tail = FALSE:
# This gives P(X > k) for a specific input value k
pbinom(11,  n_passengers, p_noshow, lower.tail=FALSE)


# visualizing the entire PMF
# use tibble to create a data frame from scratch
airlines = tibble(k=0:30,
                  prob=dbinom(k, size=140, prob=0.09))
airlines

# now visualize
ggplot(airlines) + 
  geom_col(aes(x=k, y=prob))
