library(tidyverse)
library(mosaic)

# read in data on a bunch of beers
# beer = read.csv('../data/beer.csv')

# Example 1: what fraction of beers on the market are IPAs?
head(beer)

# what fraction in this sample are IPAs?
prop(~IPA, data=beer)

# how big is the sample?
nrow(beer)

# confidence interval for this proportion based on the CLT

# step 1: plug and chug
# p = 0.206 and n = 344
# apply the formula for the standard error
se_prop = sqrt(0.206 * (1-0.206) / 344)

# step 2:
# form the confidence interval
0.206 - 2*se_prop
0.206 + 2*se_prop

# conclusion: the proportion of beers sold in Texas that are IPAS
# is somewhere between 0.16 and 0.25 with 95% confidence

# compare with prop.test: a shortcut
prop.test(~IPA, data=beer)

# compare with bootstrapping: nearly identical
boot_IPA = do(1000)*prop(~IPA, data=resample(beer))
confint(boot_IPA)

# Example 2:
# how does price elasticity differ for IPAs vs non-IPAs?
# Each beer has an estimated elasticity that comes from 
# historical sales data, so we don't have to fit the power law
# ourselves. we can just compare mean ped for IPAs and non-IPAs
ggplot(beer) + 
  geom_boxplot(aes(x=IPA, y=ped))

# looks like IPA consumers are more price sensitive
mean(ped ~ IPA, data=beer)

# how much more? about 1.31 percent difference in elasticity
diffmean(ped ~ IPA, data=beer)

# What's our level of uncertainty about the difference
# in price sensitivity?
# Let's compute a confidence interval for the difference.
# We need these summary statistics for each group:
beer %>%
  group_by(IPA) %>%
  summarize(mu = mean(ped),
            sigma = sd(ped),
            n = n())


# std error formula:
# plug and chug into the big ugly formula
std_err_diff = sqrt( (0.603^2)/273 + (0.623^2)/71 )
std_err_diff

# our observe difference was 1.31, so our interval is:
1.31 - 2*0.082
1.31 + 2*0.082

# This kind of by-hand calculation gets so tedious so quickly
# that we almost never bother.  We wanted to show you the details
# for these examples so you see what's going on under the hood.

# Compare with t.test: nearly identical
# (not _exactly_ identical b/c t.test doesn't use _exactly_ 2
# as the multiplier on the standard error)
t.test(ped ~ IPA, data=beer)


# let's compare to the bootstrap:
boot_IPA_ped = do(1000)*diffmean(ped ~ IPA, data=resample(beer))
confint(boot_IPA_ped) %>%
    mutate_if(is.numeric, round, digits=2)

# yours will differ slightly due to Monte Carlo variability
# but it should be close to (-1.47, -1.15)
# again, nearly identical to the CLT-based result.
