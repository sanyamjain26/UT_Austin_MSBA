library(tidyverse)
library(mosaic)

# read in NHANES_sleep data

ggplot(NHANES_sleep) + 
  geom_histogram(aes(x = SleepHrsNight), binwidth=1)

mean(~SleepHrsNight, data=NHANES_sleep)

# de Moivre's equation
nrow(NHANES_sleep)
sd(~SleepHrsNight, data=NHANES_sleep)

# standard error of the mean
1.32/sqrt(1991)

# compare with bootstrapping
boot_sleep = do(5000)*mean(~SleepHrsNight, data=resample(NHANES_sleep))

# calculate bootstrapped standard error: really close
sd(~mean, data=boot_sleep)

# confidence interval?

# go out 2 standard errors to either side of our estimate from the sample
6.88 - 2 * 1.32/sqrt(1991)
6.88 + 2 * 1.32/sqrt(1991)

# compare with bootstrapping
confint(boot_sleep, level = 0.95)

# Take-home lesson: you get a confidence interval that's
# basically identical to what you get when you bootstrap,
# except using math rather than computational muscle.


###
# t-test shortcut
###

# it's tedious to have to do these calculations by hand,
# i.e. treating R as a calculator and manually type out
# the formula for de Moivre's equation

# Luckily, there's a shortcut, using a built-in R command
# called t.test. It works basically just like mean, as follows:
t.test(~SleepHrsNight, data=NHANES_sleep)

# This command prints out a bunch of extraneous information
# to the console. You can safely ignore just about everything
# for now, except the part labeled 95% confidence interval


### A second example

# read in the data
# kroger = read.csv('../data/kroger.csv')

# Let's take the DFW store alone, using filter
kroger_dfw = filter(kroger, city == 'Dallas')

# What's the mean sales volume in this store?
ggplot(kroger_dfw) + 
  geom_histogram(aes(x=vol))

# mean, std dev, and sample size
favstats(~vol, data=kroger_dfw)

# de Moivre's equation says is that our standard error of the mean is
2353.645/sqrt(61)

# let's compare this with our bootstrapped standard error
boot_cheese = do(1000)*mean(~vol, data=resample(kroger_dfw))

# calculate bootstrapped standard error
# pretty close!
sd(~mean, data=boot_cheese)

# 95% bootstrap confidence interval
confint(boot_cheese)

# compare with the CLT-based confidence interval:
4356.5 - 2 * 2353.645/sqrt(61)
4356.5 + 2 * 2353.645/sqrt(61)

# doing this by hand is awful.  use t.test instead:
t.test(~vol, data=kroger_dfw)

# take-home message: again, CLT and bootstrapping
# give nearly identical confidence intervals

