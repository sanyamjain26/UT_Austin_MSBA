library(tidyverse)

# recid = read.csv("../data/recid.csv")

# Here the outcome (arrest) is itself a 0/1 variable,
# where 1 means yes (i.e. the inmate was re-arrested).
# This is perfectly OK! We can write out regression
# equations for 0/1 outcomes as well.  We should just
# interpret the results in terms of proportions.


# Graphical exploration: 
# Here's a bar plot of re-arrest rates by employment status
# and high-school diploma:
recid_summary = recid %>%
  group_by(emp1, highschool) %>%
  summarize(mean_arrest = mean(arrest))

ggplot(recid_summary) +
  geom_col(aes(x=emp1, y=mean_arrest, fill=highschool), position='dodge')

# Conclusion:  re-arrest rates are lower for those with
# high-school diplomas and for those who are employed
# within one week of release.
# The re-arrest rate for those with both looks to be zero.

# So based on the bar plot, let's fit a model with:
#  - a main effect for highschool.
#  - a main effect for emp1.
#  - an interaction between highschool and emp1.
# This will allow us to assess if the effect of employment on
# recidivism depends on whether someone has a high-school diploma.

recid_model1 = lm(arrest ~ emp1 + highschool + emp1:highschool, data=recid)
coef(recid_model1) %>%
  round(2)

# Note that R has taken our categorical variables (emp1 and highschool)
# and encoded them as dummy variables:
#  - emp1yes
#  - highschoolyes

# Interpretation: 
#  baseline re-arrest rate when emp1yes=0 and highschoolyes=0 is 30%.
# When emp1yes=1 and highschoolyes=0, re-arrest rate is 10% lower
# When emp1yes=0 and highschoolyes=1, re-arrest rate is 17% lower.
# When emp1yes=1 and highschoolyes=1, the average re-arrest rate is:  
#   -0.1 - 0.17 - 0.03 = 0.3 i.e. 30% lower.
# Remember, when both dummy variables are equal to 1, we add 
# both the main effects for each variable as well as the interaction
# between those variables to form their combined effect.

# But but but!  Look at the confidence interval:
# we notice that the interval for the interaction effect is super wide
confint(recid_model1) %>% round(2)

# It goes from -0.5 to nearly +0.5, which is nearly useless!
# we really can't estimate the value of the interaction term
# with any precision. 

# Why? only 4 inmates with both emp1 and highschool
xtabs(~emp1 + highschool, data=recid)

# This limits our ability to contrast the employment effect
# for those with versus without a high-school diploma.

# Conclusion: we're better off without an interaction term:
recid_model2 = lm(arrest ~ emp1 + highschool, data=recid)
confint(recid_model2) %>%
  round(2)

