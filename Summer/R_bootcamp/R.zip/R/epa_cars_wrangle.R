library(tidyverse)

# Import the data in epa_cars.csv

ggplot(epa_cars) + 
  geom_histogram(aes(x=cityMPG))

ggplot(epa_cars) + 
  geom_histogram(aes(x=cityMPG, y=..density..)) + 
  facet_wrap(~Powertrain)


# look at only the gas-powered cars
epa_cars_gas_summary = epa_cars %>%
  filter(Powertrain == 'Gasoline') %>%
  summarize(mean_city = mean(cityMPG),
            min_city = min(cityMPG), 
            max_city = max(cityMPG))


epa_cars %>%
  filter(cityMPG == 6)
