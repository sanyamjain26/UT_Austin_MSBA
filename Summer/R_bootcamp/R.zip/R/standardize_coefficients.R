library(tidyverse)
library(effectsize)

lm_apt = lm(twobed_rent ~ twobed_sf + distance_from_tower + furnished, data = apartments)
get_regression_table(lm_apt, conf.level = 0.95, digits=2)

apartments = apartments %>%
  mutate(feet_from_tower = distance_from_tower*5280)

lm_apt_feet = lm(twobed_rent ~ twobed_sf + feet_from_tower + furnished, data = apartments)
get_regression_table(lm_apt_feet, conf.level = 0.95, digits=2)

standardize_parameters(lm_apt)