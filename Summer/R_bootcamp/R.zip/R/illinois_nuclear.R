# 80,515 children
# 47 cancer cases
# background rate: 4.7 per 10,000 "flips" (prob = 0.00047)

NMC = 10000
cancer_mc = rbinom(NMC, size=80515, prob=4.7/10000)


hist(cancer_mc)
sum(cancer_mc >= 47)/NMC
