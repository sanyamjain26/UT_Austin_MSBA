library(tidyverse)
library(mosaic)

buildings = read.csv('../data/buildings.csv')

ggplot(buildings) + 
  geom_histogram(aes(x=Rent), bins=100)

# Three ways to calculate a mean
mean(buildings$Rent)
mean(~Rent, data=buildings)
buildings %>%
  summarize(mean_rent = mean(Rent))

# the third way generalizes to multiple summaries
buildings %>%
  summarize(mean_rent = mean(Rent), 
            median_rent = median(Rent),
            sd_rent = sd(Rent),
            iqr_rent = IQR(Rent))
