library(tidyverse)
library(mosaic)
library(moderndive)
library(effectsize)
library(stringr)

# Airbnb listings in Santa Fe, New Mexico
# airbnb = read.csv('../data/airbnb.csv')

# Start: what's the overall relationship
# between PlazaDist and Price?
ggplot(airbnb) + 
  geom_point(aes(x=PlazaDist, y=Price))

lm0 = lm(Price ~ PlazaDist, data=airbnb)
get_regression_table(lm0)

# Think and Examine:
# But this is a naive answer because bigger places tend to be 
# a bit closer.
mean(PlazaDist ~ Bedrooms, data=airbnb)

# Estimate:
# what if we adjust for size by adding bedrooms and bathrooms?
# now the distance effect looks weaker
lm1 = lm(Price ~ PlazaDist + Bedrooms + Baths, data=airbnb)
get_regression_table(lm1)

# that's because beds/baths both have large effects on y.
# and were correlated with distance.
# remember: correlated predictors lead to causal confusion!

# Refine:
# what if we further adjust for whether you're renting a house,
# versus some other type of dwelling (condo, apt, room, etc)?
airbnb %>%
  select(Style) %>%
  sample(10)
# some places are houses -- might be a premium there?

# let's use the str_detect ("string detect") function to check
# for the presence of the word "house" in the Style field
airbnb = airbnb %>%
  mutate(house = str_detect(Style, pattern = 'house'))

# Now let's refine our model by adding the house variable
lm2 = lm(Price ~ PlazaDist + Bedrooms + Baths + house, data=airbnb)
get_regression_table(lm2)

# entire looks like it has a positive coefficient,
# but the confidence interval is pretty wide
# also, the PlazaDist coefficient didn't change.
# conclusion: further adjustment for house didn't change anything
# its effect was largely redundant with bedrooms and bathrooms.
# This is one case where an ANOVA is useful:
eta_squared(lm2, partial=FALSE)

# Model 1 and Model 2 aren't saying anything different
# about the PlazaDist effect.
# Conclusion: adding house wasn't really necessary as an adjustment:
# "model robustness" or "specification robustness"
