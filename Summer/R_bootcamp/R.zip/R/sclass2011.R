library(tidyverse)
library(mosaic)

# sclass2011 = read.csv('../data/sclass2011.csv')

# let's change the units on mileage to 1K miles to make interpretation easier,
# and then estimate how price declines with mileage
sclass2011 = mutate(sclass2011, miles1K = mileage/1000)
lm0 = lm(price ~ miles1K + trim, data=sclass2011)
coef(lm0) %>% round(0)

# interpretation:
# - S550 with 0 miles costs 61500 on average
# - 63 AMGs cost about 24300 more than that
# - price goes down about $322 for each addition 1K miles on the odometer
# - this price coefficient is common to both models BY ASSUMPTION

# But we don't think that's right!
# the 63 AMG line should be steeper: higher "penalty" for more miles
# i.e. the effect of mileage on price depends on the trim
# here's a plot that shows this effect:
ggplot(sclass2011, aes(x=miles1K, y=price)) + 
  geom_point() + 
  facet_wrap(~trim) + 
  geom_smooth(method='lm') # add linear trends to each facet


# let's build a model that incorporates this effect, via an interaction
lm1 = lm(price ~ miles1K + trim + miles1K:trim, data=sclass2011)
coef(lm1) %>% round(0)
confint(lm1)

# we're pretty confident in the sign of that interaction term (definitely negative)
# so we'll keep it: seems to be a real effect
