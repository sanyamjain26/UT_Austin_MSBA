library(tidyverse)
library(mosaic)
library(foreach)
library(doParallel)


###
# Part 1: what happens when N gets bigger?
###

# read in a crazy population in crazypop2.csv
crazypop2 = read.csv('../data/crazypop2.csv')

# these individual data points are from some weird distribution
ggplot(crazypop2) +
  geom_histogram(aes(x=x), bins=100)

# let's see what happens when we repeatedly sample from crazypop2
N = 100 # size of each sample (we'll try 2, 5, 25, and 100)
sim2 = do(5000)*mean(~x, data=sample(crazypop2, size=N))

ggplot(sim2) +
  geom_histogram(aes(x=mean), bins=500) + 
  xlim(range(crazypop2))

# What happens as N grows?
# 1) the distribution of the means gets narrower
# 2) the sampling distribution looks more and more like a normal distribution


###
# part 2: de Moivre's equation
###

# Let's compare the theoretical std error
# with the actual std error from our Monte Carlo sim

# possible values of n
n_grid = c(2, 5, 10, 20, 30, 50, 75, 100, 150, 200, 500, 1000)


# how many cores to use?
detectCores()
registerDoParallel(6)

# outer loop
stderr_grid = foreach(N = n_grid, .combine='c') %dopar% {
  # inner loop: simulate the sampling distribution of the mean
  sim_this_n = do(10000, parallel=FALSE)*mean(~x, data=sample(crazypop2, size=N))
  stderr_xbar = sd(~mean, data=sim_this_n)
  stderr_xbar
}

# What would de Moivre predict?
sigma = sd(~x, data=crazypop2)
sigma/sqrt(n_grid)

demoivre_grid = tibble(n = n_grid,
                       se_mc = stderr_grid,
                       se_theory = sigma/sqrt(n_grid))

# standard errors from simulation
p0 = ggplot(demoivre_grid) + 
  geom_point(aes(x=n, y=se_mc))
p0

# add the theoretical std errs from de Moivre:
p0 + geom_line(aes(x=n, y=se_theory))
p0 + geom_line(aes(x=n, y=se_theory)) + scale_x_log10()


###
# Part 3: CLT with de Moivre's equation
###

# population parameters
mu = mean(~x, data=crazypop2)
mu

sigma = sd(~x, data=crazypop2)
sigma

# let's use de Moivre's equation + CLT to predict what the
# sampling distribution of the mean should look like.
N = 100 # size of each sample (we'll try 5, 25, and 100)
sim2 = do(5000)*mean(~x, data=sample(crazypop2, size=N))

# de Moivre's equation:
stderr_thisN = sigma/sqrt(N)

# actual sampling distribution
p1 = ggplot(sim2) +
  geom_histogram(aes(x=mean, y=..density..), bins=30)
p1

# this is the normal density predicted by de Moivre + CLT
mydens = function(x) {
  dnorm(x, mu, stderr_thisN)
}

# sampling distribution + prediction
p1 + stat_function(fun = mydens, col='blue', size=2)

