# load the tidyverse (https://www.tidyverse.org/)
library(tidyverse)

## Use the Import Dataset button under the "Environment" tab to the right
## Follow the prompts

# OR: read in the data set using read.csv,
# using the full path name to the file you want to import
# you don't need to do both!
# So if you used the Import Dataset button, skip the command below
plays_top50 = read.csv('../data/plays_top50.csv')

# look at the data set
View(plays_top50)

# how big is the data set?
dim(plays_top50)   # 15,000 rows, 51 columns)

# cross tabulate the data by a particular pair of artists
# this is just counting combinations of 0's and 1's.
xtabs(~franz.ferdinand + the.killers, data=plays_top50)

# What is P(plays franz ferdinand)?
# we can treat R just like a calculator...
(571 + 319)/15000

# What is P(plays franz ferdinand | plays the killers)?  
319/(319 + 1154)

## You try these two...

# What are P(plays bob dylan) and P(plays bob dylan | plays the beatles)?  
xtabs(~bob.dylan + the.beatles, data=plays_top50)

# What are P(plays rihanna) and P(plays rihanna | plays kanye west)?  
xtabs(~kanye.west + rihanna, data=plays_top50)



###
# counts into frequencies
###

# Turn counts into proportions.
# This makes the whole table sum to 1.
# we "pipe" the table of counts into the "prop.table" function
xtabs(~franz.ferdinand + the.killers, data=plays_top50) %>%
  prop.table()

# can also add probabilities in the margins:
xtabs(~franz.ferdinand + the.killers, data=plays_top50) %>%
  prop.table() %>%
  addmargins()

# Condition on the first variable we named (margin=1).
# This makes the rows sum to 1.
xtabs(~franz.ferdinand + the.killers, data=plays_top50) %>%
  prop.table(margin=1)

# Condition on the second variable we named (margin=2)
# This make the columns sum to 1.
xtabs(~franz.ferdinand + the.killers, data=plays_top50) %>%
  prop.table(margin=2)
