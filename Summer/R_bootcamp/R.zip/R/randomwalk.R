library(tidyverse)
library(lubridate)
library(mosaic)

# simulate from the normal random walk model:
# y_t = y_{t-1} + e_t, where e_t is N(0, sigma)

# writing our own function: simulation of random walk
normal_random_walk = function(y0, sigma, n_steps) {
  
  # 1) set up a vector that tracks our random walk
  y_history = rep(y0, n_steps)
  
  # 2) initialize the value of the random walk
  y = y0
  
  # 3) Loop n_steps of the random walk
  for(i in 1:n_steps) {
    shock = rnorm(1, mean=0, sd=sigma)
    y = y + shock # update value of y
    y_history[i] = y # save y
  }
  
  # return the simulated y_history
  y_history
}

# start with an initial price
normal_random_walk(y0 = 50, sigma=1, n=390)

# let's save one in a tibble and plot it
sim1 = tibble(t = 1:390,
  price_history = normal_random_walk(50, sigma=0.05, n=390))

ggplot(sim1) + 
  geom_line(aes(x=t, y=price_history))


####
# now for some data and the real fun!
####

# read in the AAPL data frame
AAPL = read.csv('../data/AAPL.csv')
head(AAPL)

# tell R that time_stamp is a date
AAPL = AAPL %>%
  mutate(time_stamp = ymd_hms(time_stamp))

# the intra-day price at the end of each minute
ggplot(AAPL) +
  geom_line(aes(x=time_stamp, y=price))

# Let's calculate the minute-to-minute differences in price.
# this is easy to do using the "lag" function,
# which takes the price on the previous row
AAPL = AAPL %>%
  mutate(shock = price - lag(price, n=1))


# first several lines
head(AAPL)

# std dev of of the minute-to-minute shocks
favstats(~shock, data= AAPL)

# histogram of these shocks:
# normal not perfect but not terrible
ggplot(AAPL) +
  geom_histogram(aes(x=shock))

# Let's use this to simulate what AAPL stock might look like tomorrow

# what was the previous day's closing price?
tail(AAPL)

# looks like 119.36
# we'll use that as a starting price to simulate the next day
initial_price = 119.36
sigma = 0.0694  # our minute-to-minute standard deviation
  # try running sd(diff(AAPL$price))

# let's simulate 10000 intra-day trajectories for AAPL
# the inner loop involves our normal_random_walk function
AAPL_intraday = do(10000)*{
  # simulate the random walk
  price_history = normal_random_walk(initial_price, sigma, 390)
  
  # collect the max and min intra-day values
  c(min_intraday=min(price_history), max_intraday=max(price_history))
}


# What can we do with this?

# Application 1:
# calculate the probability that a stop-loss order will trigger.
# Suppose we put a 2.5% stop-loss on AAPL
# That is, we exit our position and sell AAPL if the price
# hits a level 2.5% below the open.
# This will happen if the price hits our stop-loss threshold
# at any point in the day.  So look at the min intra-day price

stop_loss = 0.975*initial_price
stop_loss

ggplot(AAPL_intraday) +
  geom_histogram(aes(x=min_intraday))


# let's calculate how many simulated trajectories
# had a minimum that went below our "stop-loss" level
AAPL_intraday %>%
  summarize(n_stoploss = count(min_intraday < stop_loss))


# Application 2: options pricing.
# Suppose we've bought a "call" option on our AAPL stock
# with a strike price of $121.50.  If the price hits $121.50,
# our call option will be "in the money."
# If that happens, we win, because we can buy AAPL stock
# for $121.50, rather than the current (higher) market price.

ggplot(AAPL_intraday) +
  geom_histogram(aes(x=max_intraday))


# how likely is AAPL stock to hit our strike price?
# look at the max price
AAPL_intraday %>%
  summarize(n_ITM = sum(max_intraday > 121.50))

# roughly a 10% chance our option reaches "in the money" today
# this random walk model is the heart of what's called the Black-Scholes
# model for pricing options in finance 