library(ggplot2)
library(tidyverse)
library(mosaic)
source('https://tinyurl.com/y4krd9uy') # simple_anova function


sat = read.csv('../data/sat.csv')
# This data frame contains the following columns:
# expend:  expenditure per pupil in public schools in 1994-95 (thousands of dollars)
# ratio: pupil/teacher ratio in public schools, Fall 1994
# salary: average salary of teachers, 1994-95 (thousands of dollars)
# takers: Percentage of all eligible students taking the SAT, 1994-95
# verbal: Average verbal SAT score, 1994-95
# math: Average math SAT score, 1994-95
# total: average total score on the SAT, 1994-95


# Let's begin by looking at the relationship between total SAT score (0-1600 in 1994)
# and per-pupil expenditures
# Sure enough: the lines slopes down
ggplot(sat, aes(x=expend, y=total)) + 
  geom_point() + 
  geom_smooth(method='lm', se=FALSE)


fit1 = lm(total~expend, data=sat)
coef(fit1) %>% round(0)

# Checking with the bootstrap: a 95% CI that includes
# only negative values
boot1 = do(1000)*lm(total~expend, data=resample(sat))
confint(boot1)

# you might think those four states at the right right look like outliers
# and are pulling the overall line down.
# let's check!
fit2 = lm(total~expend, data=filter(sat, expend<8))
coef(fit2)
coef(fit1) # for comparison
# Nope -- the slope actually gets steeper downwards if we remove them!

# What's going on?
# We're missing a lurking variable: The rate of participation 
# in the SAT.

# SAT partipation rates  (the takers variable) vary a lot between states:
ggplot(sat) + 
  geom_histogram(aes(x=takers))

# One explanation for that is just that different states have different proportions
# of students interested in attending college, for various reasons (demographics and so on).

# Another big reason for the variability is that during this time period, different 
# schools/geographic areas had different test requirements or preferences -- 
# some preferred SAT, some ACT, and not every school accepted both. So in some states
# you might not need to take the SAT to attend a state school while in others you'd be
# required to take it. 

# However, most applicants to elite or out-of-state schools were taking the SAT. 
# Therefore, in states with low SAT participation, the SAT-taking population was 
# disproportionally higher-performing students. We see this in the data:
ggplot(sat, aes(x=takers, y=total)) + 
  geom_point() + 
  geom_smooth(method='lm', se=FALSE)

# In states where participation is low, it is disproportionately better students taking
# the SAT, leading to this strong negative correlation:
# the higher the participation rate, the lower the state's average score

# And prticipation rates are also correlated with student expenditures:
ggplot(sat, aes(x=takers, y=expend)) + 
  geom_point() + 
  geom_smooth(method='lm', se=FALSE)
# states that spend more on education tend to have higher participation rates.
# that's probably a major policy goal of more spending!
# i.e. prepare more of your students to be college ready

# When we ignore the effect of participation rates on average SAT scores (in SLR),
# the correlation between particpation and expenditures allows expenditures
# to work as a "proxy" for participation rates, leading us astray!

# We need to adjust for this lurking variable, similar to how we adjusted for
# neighborhood in thinking about the effect of size (sqft) on house price

# An easy way to do this is to isolate the states with a given level of participation.

# Let's try this:
favstats(sat$takers)
# looks like the quartiles of participation are:
# 0-9: bottom quartile of states
# 10-28: second quartile
# 28-63: third quartile
# above 63: top quartile

# Below we highlight the states in quartile 1
ggplot(sat) + 
  geom_point(aes(x=expend, y=total,
                 color = (takers < 10)))
# in these states we see a positive relationship!

# what about states between 10 and 28, the second quartile?
ggplot(sat) + 
  geom_point(aes(x=expend, y=total,
                 color = (takers >= 10 & takers < 28)))
# again, a slightly positive relationship

# what about states between 28 and 63, the third quartile?
ggplot(sat) + 
  geom_point(aes(x=expend, y=total,
                 color = (takers >= 28 & takers < 63)))
# not many of them, but still looks positive

# what about states with takers >+ 63 (top quartile)
ggplot(sat) + 
  geom_point(aes(x=expend, y=total,
                 color = (takers >= 63)))
# again, a positive or possibly flat relationship


# let's see what happens when we explicitly include the 
# quartile as a categorical predictor
sat = mutate(sat, takers_quartile = ntile(takers, 4))

# here's a plot where we stratify the states by quartile
ggplot(sat, aes(x=expend, y=total)) + 
  geom_point() +
  facet_wrap(~takers_quartile) +
  geom_smooth(method='lm', se=FALSE)


####
# Multiple Linear Regression for Adjustment
####

# Multiple linear regression lets us make the necessary adjustment
# using a model instead of data subsetting...
# We assume that
# (total sat) = beta_0 + beta_1(school expenditures) + beta_2(participation) + (residual)
# The coefficient beta_1 represents the change in expected SAT scores for 
# a one-unit (i.e. $1000) increase in expenditures, **holding constant**
# the SAT participation rate

fit3 = lm(total~expend+takers, data=sat)
coef(fit3) %>% round(1)

# let's get some bootstrapped confidence intervals
boot3 = do(1000)*lm(total~expend+takers, data=resample(sat)) 
confint(boot3)

# Conclusion:
# When controlling for the SAT participation rate -- estimating the relationship
# between expenditures and average SAT scores within schools that have the same
# level of SAT participation -- we see that there is actually a positive partial 
# association between school expenditures and SAT scores


######
# Optional plots for the brave
######

# here's the plot from the notes that shows the state labels
ggplot(sat, aes(x=expend, y=total)) + 
geom_text(aes(label=State), size=2, col='darkgreen', alpha=0.7) + 
  labs(x = "Expenditure Per Pupil ($1000)", 
       y = "Average Total SAT") + 
  geom_smooth(method='lm', se=FALSE)


# a plot that shows both the overall and partial relationship
# here's a plot where we stratify the states by quartile

ggplot(sat) + 
  geom_point(aes(x=expend, y=total, color=factor(takers_quartile))) +
  geom_smooth(aes(x=expend, y=total, color=factor(takers_quartile)), method='lm', se=FALSE) + 
  geom_smooth(aes(x=expend, y=total), color='black', method='lm', se=FALSE) + 
  labs(x = "Expenditure Per Pupil ($1000)", 
       y = "Average Total SAT", 
       color="SAT Participation \nRate Quartile") + 
  theme(legend.position="bottom") + 
  scale_colour_discrete(type=wesanderson::wes_palette("GrandBudapest2"))

