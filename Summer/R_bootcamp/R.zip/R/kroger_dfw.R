library(tidyverse)
library(mosaic)

kroger = read.csv('../data/kroger.csv')

# Let's take the DFW store alone, using filter
kroger_dfw = filter(kroger, city == 'Dallas')

# visualization with a jitter plot
# width controls the horizontal jitter
ggplot(kroger_dfw) + 
  geom_jitter(aes(x=disp, y=vol), width=0.1)

# group means and their difference
mean(vol ~ disp, data=kroger_dfw)
diffmean(vol ~ disp, data=kroger_dfw)

# the same information expressed by a regression model in baseline/offset form
model_kroger_dfw = lm(vol ~ disp, data=kroger_dfw)

# the coefficients
# the dispyes coefficient tells us the offset:
# the difference between display weeks and non-display weeks
coef(model_kroger_dfw)

# how do we know that no is the baseline and yes is the dummy variable?
kroger_dfw %>%
  count(disp)

# the model's R-squared
rsquared(model_kroger_dfw, data=kroger_dfw)

# why use lm when mean and diffmean give the same answer?
# because lm can be generalized
# it works both with categorical and quantitative variables
# also, it will work with more than one explanatory variable... coming soon!
