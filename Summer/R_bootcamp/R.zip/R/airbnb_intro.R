library(tidyverse)

# Airbnb listings in Santa Fe, New Mexico
# Use Import Dataset button to read in airbnb.csv:
# 1) Go to the Environment tab in RStudio's top-right panel.
# 2) Click the Import Dataset button. You'll see a pop-up menu.
# 3) Choose the first option: From Text (base)....
# 4) Navigate to wherever you saved the airbnb.csv file.
# 5) When you find it, click Open. Follow the prompts.

# the whole data set in a viewer window
View(airbnb)

# Question 1: what is the distribution of bedrooms/bathrooms in this sample?
# let's answer this with a table of counts.
xtabs(~ Bedrooms + Baths, data=airbnb)

# Question 2: how does price fall off with distance to the Plaza?
# let's address this with a scatter plot of Price vs PlazaDist
ggplot(airbnb) +
  geom_point(aes(x=PlazaDist, y=Price))

# Question 3: how do prices increase as a function of bedrooms?
# Let's address this by calculating the mean price (and sample size)
# for each different value of the Bedrooms variable
 

# This short example illustrates the steps of any data analysis in R:
# - import a data set from an external file.
# - decide what questions you want to ask about the data.
# - write a script that answers those questions (statistics/tables/plots/etc).
# - run the script to see the results.
